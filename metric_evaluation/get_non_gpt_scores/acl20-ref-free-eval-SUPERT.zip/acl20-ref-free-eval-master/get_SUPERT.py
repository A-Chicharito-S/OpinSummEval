import sys
sys.path.append('../')
import numpy as np
import os
import json
from ref_free_metrics.supert import Supert
from utils.data_reader import CorpusReader
from tqdm import tqdm

if __name__ == '__main__':
    f = open('supert_score.jsonl', 'w')
    # pseudo-ref strategy:
    # * top15 means the first 15 sentences from each input doc will be used to build the pseudo reference summary
    pseudo_ref = 'top15'
    for i in tqdm(range(100)):
        inst_dict = {'case': i+1}
        score_dict = {}
        # read source documents
        reader = CorpusReader('yelp_data/topic_'+str(1000+i+1))
        source_docs = reader()
        summaries = reader.readSummaries()

        # get unsupervised metrics for the summaries
        supert = Supert(source_docs, ref_metric=pseudo_ref)
        scores = supert(summaries)
        assert len(scores) == 14

        model_names = sorted(os.listdir('yelp_data/topic_'+str(1000+i+1)+'/summaries'))
        for j, name in enumerate(model_names):
            name = name.replace('summary', '')
            name = name.replace('.txt', '')
            score_dict[name] = scores[j]

        inst_dict['supert_score'] = score_dict
        f.write(json.dumps(inst_dict)+'\n')





