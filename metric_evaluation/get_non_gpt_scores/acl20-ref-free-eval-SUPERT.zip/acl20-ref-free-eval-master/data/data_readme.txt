Create a folder for each topic you want to evaluate/summarize. Inside the topic folder, 
* put the to-be-summarised documents to input_docs/,
* put the to-be-evaluated summaries to summaries/, and 
* if human-written reference summaries are available, put them to references/.

An example is provided here. It is from DUC'09, topic 0939-A.
