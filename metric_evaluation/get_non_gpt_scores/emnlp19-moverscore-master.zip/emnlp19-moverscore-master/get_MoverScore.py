from moverscore_v2 import word_mover_score
from collections import defaultdict
import numpy as np
import json
from tqdm import tqdm


def sentence_score(hypo: str, ref: str, trace=0):
    idf_dict_hyp = defaultdict(lambda: 1.)
    idf_dict_ref = defaultdict(lambda: 1.)

    hypothesis = [hypo]
    references = [ref]

    scores = word_mover_score(references, hypothesis, idf_dict_ref, idf_dict_hyp, stop_words=[], n_gram=1,
                              remove_subwords=False)

    sentence_score = np.mean(scores)

    if trace > 0:
        print(hypothesis, references, sentence_score)

    return sentence_score


f = open('14model_outputs.jsonl', 'r')
new_f = open('moverscore_14model_outputs.jsonl', 'w')
total_list = []

for i, line in enumerate(tqdm(f)):
    inst = json.loads(line)

    ref = inst['summ']

    new_inst = {'revs': inst['revs'], 'summ': ref, 'case': inst['case']}

    model_outputs_dict = inst['model_output']
    new_model_outputs = {}
    assert i + 1 == int(inst['case'])
    keys = list(model_outputs_dict.keys())
    keys.sort()

    assert len(keys) == 14

    sorted_keys = keys

    for key in sorted_keys:
        hypo = model_outputs_dict[key]
        score = sentence_score(hypo=hypo, ref=ref)
        new_model_outputs[key] = {'model_summ': hypo, 'mover_score': score}

    new_inst['model_output'] = new_model_outputs
    new_f.write(json.dumps(new_inst) + '\n')

new_f.close()
