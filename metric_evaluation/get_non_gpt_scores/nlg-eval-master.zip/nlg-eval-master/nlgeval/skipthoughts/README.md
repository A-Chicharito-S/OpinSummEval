# skip-thoughts

Original README can be found at [ryankiros/skip-thoughts](https://github.com/ryankiros/skip-thoughts/blob/6661cad40664b6c251cac1dad779986eb332c26a/README.md).

## License

All files in the skipthoughts directory are under
[Apache License 2.0](http://www.apache.org/licenses/LICENSE-2.0)
to the authors of [ryankiros/skip-thoughts](https://github.com/ryankiros/skip-thoughts/tree/6661cad40664b6c251cac1dad779986eb332c26a).
