from nlgeval import NLGEval
import json
from tqdm import tqdm

f = open('14model_outputs.jsonl', 'r')
new_f = open('nlgeval_14model_outputs.jsonl', 'w')
total_list = []

nlgevaluator = NLGEval(no_skipthoughts=False)  # loads the models
for i, line in enumerate(tqdm(f)):
    inst = json.loads(line)

    ref = inst['summ']
    new_inst = {'revs': inst['revs'], 'summ': ref, 'case': inst['case']}

    model_outputs_dict = inst['model_output']
    new_model_outputs = {}
    assert i + 1 == int(inst['case'])
    keys = list(model_outputs_dict.keys())
    keys.sort()

    assert len(keys) == 14

    sorted_keys = keys

    for key in sorted_keys:
        hypo = model_outputs_dict[key]
        score_dict = metrics_dict = nlgevaluator.compute_individual_metrics(ref=[ref], hyp=hypo)
        score_dict.pop('CIDEr')
        for score_key in score_dict.keys():
            score_dict[score_key] = float(score_dict[score_key])
        # exemplary output: {'Bleu_1': 0.9999999993333338, 'Bleu_2': 0.9999999992500005, 'Bleu_3': 0.9999999990555564,
        # 'Bleu_4': 0.03162277657664911, 'METEOR': 1.0, 'ROUGE_L': 1.0, 'CIDEr': 0.0, 'SkipThoughtCS': 1.0000002,
        # 'EmbeddingAverageCosineSimilarity': 1.0, 'EmbeddingAverageCosineSimilairty': 1.0,
        # 'VectorExtremaCosineSimilarity': 1.0, 'GreedyMatchingScore': 1.0}
        new_model_outputs[key] = {'model_summ': hypo, 'NLGEval_score': score_dict}

    new_inst['model_output'] = new_model_outputs
    new_f.write(json.dumps(new_inst) + '\n')

new_f.close()
