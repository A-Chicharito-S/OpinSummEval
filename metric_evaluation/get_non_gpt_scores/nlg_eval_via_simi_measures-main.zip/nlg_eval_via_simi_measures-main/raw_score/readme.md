

This folder gather some early raw scores of the paper and are a partial and quick answer to https://github.com/PierreColombo/nlg_eval_via_simi_measures/issues/3.
