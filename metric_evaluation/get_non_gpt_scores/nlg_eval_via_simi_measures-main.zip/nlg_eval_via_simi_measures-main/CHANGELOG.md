# Changelog
All notable changes to this project will be documented in this file.

## [UnReleased] - 2022-MM-DD

### Added:

- Added `BaryScore` metric

- Added `InfoLM` metric

- Added `DepthScore` metric
