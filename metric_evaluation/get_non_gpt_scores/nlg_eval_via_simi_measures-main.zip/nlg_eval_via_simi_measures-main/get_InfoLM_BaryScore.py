from nlg_eval_via_simi_measures.bary_score import BaryScoreMetric
from nlg_eval_via_simi_measures.infolm import InfoLM


def get_bary_score(hypo, ref, metric):
    # metric = BaryScoreMetric(use_idfs=False)
    reference = [ref]
    hypothesis = [hypo]

    metric.prepare_idfs(refs=reference, hyps=hypothesis)
    pred_dict = metric.evaluate_batch(batch_refs=reference, batch_hyps=hypothesis)

    return pred_dict

# {'baryscore_W': [2.220446049250313e-16, 0.49367367503857573], 'baryscore_SD_10': [0.9234964207672105,
# 1.0454138637845445], 'baryscore_SD_1': [0.7360736780238415, 0.9437504295589365], 'baryscore_SD_5': [
# 0.9074754173121329, 1.0362071204461292], 'baryscore_SD_0.1': [0.0007089175353201491, 0.5100519520716396],
# 'baryscore_SD_0.5': [0.46239889706639015, 0.8098910977521676], 'baryscore_SD_0.01': [2.220446049250317e-16,
# 0.4936736758585288], 'baryscore_SD_0.001': [2.220446049250313e-16, 3.1188586838975006e-08]}


def get_infoLM_score(hypo, ref, metric):
    metric_dict = {}
    # metric = InfoLM(measure_to_use='ab', alpha=0.25, beta=0.25, temperature=1, use_idf_weights=False)
    reference = [ref]
    hypothesis = [hypo]
    idf_ref, idf_hypot = metric.prepare_idfs(refs=reference, hyps=hypothesis)

    pred_dict = metric.evaluate_batch(batch_refs=reference, batch_hyps=hypothesis)

    metric_dict['ab_div'] = pred_dict

    return metric_dict



import json
from tqdm import tqdm

f = open('14model_outputs.jsonl', 'r')
new_f = open('infoLM_14model_outputs.jsonl', 'w')
total_list = []

bary_scorer = BaryScoreMetric(use_idfs=False)
infoLM_scorer = InfoLM(measure_to_use='ab', alpha=0.25, beta=0.25, temperature=1, use_idf_weights=False)

for i, line in enumerate(tqdm(f)):
    inst = json.loads(line)

    ref = inst['summ']

    new_inst = {'revs': inst['revs'], 'summ': ref, 'case': inst['case']}

    model_outputs_dict = inst['model_output']
    new_model_outputs = {}
    assert i + 1 == int(inst['case'])
    keys = list(model_outputs_dict.keys())
    keys.sort()

    assert len(keys) == 14

    sorted_keys = keys
    for key in sorted_keys:
        hypo = model_outputs_dict[key]
        bary_score_dict = get_bary_score(hypo=hypo, ref=ref, metric=bary_scorer)
        infoLM_score_dict = get_infoLM_score(hypo=hypo, ref=ref, metric=infoLM_scorer)

        new_model_outputs[key] = {'model_summ': hypo, 'bary_score': bary_score_dict, 'infoLM_score': infoLM_score_dict}

    new_inst['model_output'] = new_model_outputs
    new_f.write(json.dumps(new_inst) + '\n')

new_f.close()
