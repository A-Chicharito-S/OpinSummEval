from summaqa import QG_masked
from summaqa import QA_Metric
import json
from tqdm import tqdm

question_generator = QG_masked()
qa_metric = QA_Metric()


f = open('14model_outputs.jsonl', 'r')
new_f = open('summaqa_14model_outputs.jsonl', 'w')
total_list = []

for i, line in enumerate(tqdm(f)):
    inst = json.loads(line)

    ref = inst['summ']
    revs_dict = inst['revs']

    new_inst = {'revs': revs_dict, 'summ': ref, 'case': inst['case']}

    article = []
    for j in range(8):
        article.append(revs_dict['rev' + str(j + 1)])
    article = ' '.join(article)

    masked_questions, answer_spans = question_generator.get_questions(article)

    model_outputs_dict = inst['model_output']
    new_model_outputs = {}
    assert i + 1 == int(inst['case'])
    keys = list(model_outputs_dict.keys())
    keys.sort()

    assert len(keys) == 14

    sorted_keys = keys

    for key in sorted_keys:
        hypo = model_outputs_dict[key]
        score_dict = qa_metric.compute(masked_questions, answer_spans, hypo)
        # exemplary output: {'avg_prob': xxx, 'avg_fscore': xxx}
        new_model_outputs[key] = {'model_summ': hypo, 'summa_qa_score': score_dict}

    new_inst['model_output'] = new_model_outputs
    new_f.write(json.dumps(new_inst) + '\n')

new_f.close()
