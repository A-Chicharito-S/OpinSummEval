#!/usr/bin/env python
# -*- coding: utf-8 -*-

import S3
import os
import word_embeddings
import click
import json
from tqdm import tqdm

# references = [["The thinning of glaciers and ice shelves, as well as the softening of the permafrost, has accelerated greatly in recent years.\
# While it is not certain that the man-made greenhouse effect is entirely to blame, it is clear that man must take steps now to address the problem.\
# Global warming affects everything: oil-platforms, the society of peoples who are indiginous to the polar regions, polar animals, migratory birds, lakes (which are drying up as the permafrost melts), and even tourism.\
# As melting cold fresh water enters the salty sea, it will affect ocean currents and therefore world climate."],
#               ["In Antarctica and the Artic, ice melts are causing complex questions about the impact of global warming.\
# In Antarctica huge glaciers are thinning and ice shelves are either disintegrating or retreating.\
# These findings are possible indications of global warming.\
# Information gathered about Antarctica coincides with a recent report on accelerating climate changes in the Arctic.\
# A Chinese scientist predicted that the Artic icecap would melt by 2080.\
# The Arctic's indigenous people (about 4 million) are fighting global warming because it will be a threat to their societies, economies and culture."],
#               ]
#
# system_summary = ["Interior Alaska's permafrost has warmed in some places to the highest level since the ice age ended 10,000 years ago, its temperature now within a degree or two of thawing.\
#   Earth frozen since woolly mammoths and bison wandered Interior steppes has been turning to mush. Lakes have been shrinking. Trees are stressed. Prehistoric ice has melted underground, leaving voids that collapse into sinkholes. \
#  Largely concentrated where people have disturbed the surface, such damage can be expensive, even heartbreaking. It's happening now in Fairbanks: Toppled spruce, roller-coaster bike trails, rippled pavement, homes and buildings that sag into ruin.",
#                   "Interior Alaska's permafrost has warmed in some places to the highest level since the ice age ended 10,000 years ago, its temperature now within a degree or two of thawing.\
#                     Earth frozen since woolly mammoths and bison wandered Interior steppes has been turning to mush. Lakes have been shrinking. Trees are stressed. Prehistoric ice has melted underground, leaving voids that collapse into sinkholes. \
#                    Largely concentrated where people have disturbed the surface, such damage can be expensive, even heartbreaking. It's happening now in Fairbanks: Toppled spruce, roller-coaster bike trails, rippled pavement, homes and buildings that sag into ruin."
#                   ]


@click.command()
@click.argument('embs_path', type=click.Path(exists=True))
@click.argument('model_folder', type=click.Path(exists=True))
@click.argument('yelp_text_path', type=click.Path(exists=True))
def run_yelp(embs_path, model_folder, yelp_text_path):
    word_embs = word_embeddings.load_embeddings(embs_path)
    f = open(yelp_text_path, 'r')
    new_f = open('../s3_14model_outputs_test.jsonl', 'w')

    for i, line in enumerate(tqdm(f)):
        inst = json.loads(line)

        ref = inst['summ']
        new_inst = {'revs': inst['revs'], 'summ': ref, 'case': inst['case']}

        model_outputs_dict = inst['model_output']
        new_model_outputs = {}
        assert i + 1 == int(inst['case'])
        keys = list(model_outputs_dict.keys())
        keys.sort()

        assert len(keys) == 14

        sorted_keys = keys
        print(sorted_keys)
        for key in sorted_keys:
            print(key)
            hypo = model_outputs_dict[key]
            result = S3.S3([[ref]], [hypo], word_embs, model_folder)
            print(result)
            new_model_outputs[key] = {'model_summ': hypo,
                                      's3_score': {'pyramid': result[0], 'responsiveness': result[1]}}
            print(new_model_outputs)
        new_inst['model_output'] = new_model_outputs
        new_f.write(json.dumps(new_inst) + '\n')

    new_f.close()


# def run_example(embs_path, model_folder):
#     word_embs = word_embeddings.load_embeddings(embs_path)
#     result = S3.S3(references, system_summary, word_embs, model_folder)


if __name__ == '__main__':
    # run_example()
    run_yelp()
