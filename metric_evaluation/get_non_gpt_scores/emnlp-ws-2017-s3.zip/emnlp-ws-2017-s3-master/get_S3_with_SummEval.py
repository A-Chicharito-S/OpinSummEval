from summ_eval.s3_metric import S3Metric
import json
from tqdm import tqdm

s3_score = S3Metric()

f = open('14model_outputs.jsonl', 'r')
new_f = open('s3_score_14model_outputs_trail_run.jsonl', 'w')
total_list = []

for i, line in enumerate(tqdm(f)):
    inst = json.loads(line)

    ref = inst['summ']

    refs = [ref] * 14

    new_inst = {'revs': inst['revs'], 'summ': ref, 'case': inst['case']}

    model_outputs_dict = inst['model_output']
    new_model_outputs = {}
    assert i + 1 == int(inst['case'])
    keys = list(model_outputs_dict.keys())
    keys.sort()

    assert len(keys) == 14

    sorted_keys = keys
    print(sorted_keys)
    hypos = []
    for key in sorted_keys:
        hypos.append(model_outputs_dict[key])

    scores_list = s3_score.evaluate_batch(summaries=hypos, references=refs)

    assert len(scores_list) == 14

    for j, key in enumerate(sorted_keys):
        new_model_outputs[key] = {'model_summ': hypos[j], 's3_score': scores_list[j]}

    new_inst['model_output'] = new_model_outputs
    new_f.write(json.dumps(new_inst) + '\n')

new_f.close()


