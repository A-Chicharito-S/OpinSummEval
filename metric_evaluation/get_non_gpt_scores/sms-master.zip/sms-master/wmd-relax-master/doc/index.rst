.. wmd-relax documentation master file, created by
   sphinx-quickstart on Mon Jun  5 16:52:34 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

wmd-relax's documentation
=========================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. automodule:: wmd
    :members:

`Doxygen docs <../../doxyhtml/files.html>`_

Doxygen docs
============

`Doxygen docs <../../doxyhtml/files.html>`_


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
