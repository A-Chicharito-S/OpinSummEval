from questeval.questeval_metric import QuestEval
import json
from tqdm import tqdm

questeval = QuestEval(no_cuda=True)

f = open('14model_outputs.jsonl', 'r')
new_f = open('questeval_14model_outputs.jsonl', 'w')
total_list = []

for i, line in enumerate(tqdm(f)):
    inst = json.loads(line)

    ref = inst['summ']
    revs_dict = inst['revs']

    new_inst = {'revs': revs_dict, 'summ': ref, 'case': inst['case']}

    article = []
    for j in range(8):
        article.append(revs_dict['rev' + str(j + 1)])
    article = ' '.join(article)

    model_outputs_dict = inst['model_output']
    new_model_outputs = {}
    assert i + 1 == int(inst['case'])
    keys = list(model_outputs_dict.keys())
    keys.sort()

    assert len(keys) == 14

    sorted_keys = keys
    hypos = []
    for key in sorted_keys:
        hypos.append(model_outputs_dict[key])

    scores_list = questeval.corpus_questeval(
        hypothesis=hypos,
        sources=[article] * 14,
        list_references=[[ref]] * 14
    )['ex_level_scores']

    assert len(scores_list) == 14
    for j, key in enumerate(sorted_keys):
        new_model_outputs[key] = {'model_summ': hypos[j], 'questeval_score': scores_list[j]}

    new_inst['model_output'] = new_model_outputs
    new_f.write(json.dumps(new_inst) + '\n')

new_f.close()
