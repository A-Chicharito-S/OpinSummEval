from bleurt import score
import json
from tqdm import tqdm

f = open('14model_outputs.jsonl', 'r')
new_f = open('bleurt_14model_outputs.jsonl', 'w')
total_list = []
checkpoint = "BLEURT-20"
bleurt_scorer = score.BleurtScorer(checkpoint)

for i, line in enumerate(tqdm(f)):
    inst = json.loads(line)

    ref = inst['summ']
    refs = [ref] * 14
    new_inst = {'revs': inst['revs'], 'summ': ref, 'case': inst['case']}

    model_outputs_dict = inst['model_output']
    new_model_outputs = {}
    assert i + 1 == int(inst['case'])
    keys = list(model_outputs_dict.keys())
    keys.sort()

    assert len(keys) == 14

    sorted_keys = keys
    hypos = []
    for key in sorted_keys:
        hypos.append(model_outputs_dict[key])

    scores_list = bleurt_scorer.score(references=refs, candidates=hypos)

    assert len(scores_list) == 14
    for j, key in enumerate(sorted_keys):
        new_model_outputs[key] = {'model_summ': hypos[j], 'bleurt_score': scores_list[j]}

    new_inst['model_output'] = new_model_outputs
    new_f.write(json.dumps(new_inst) + '\n')

new_f.close()


# references = ["This is a test."]
# candidates = ["This is the test."]

# scores = scorer.score(references=references, candidates=candidates)
# assert isinstance(scores, list) and len(scores) == 1
# print(scores, type(scores[0]))