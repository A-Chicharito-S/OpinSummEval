Nedávné nabídky evakuace tvoří režim a Rusko znělo jako slabě zahalené výhrůžky, uvedli chirurgové pastevci a další lékaři.
Lékaři uvedli, že minulý měsíc došlo k 42 útokům na zdravotnická zařízení v Sýrii, 15 z nich byly nemocnice, ve kterých pracují.
Co nás nejvíc trápí, protože lékaři si vybírají, kdo bude žít a kdo zemře.
Malé děti jsou někdy přivedeny do našich nouzových pokojů tak těžce raněných, že musíme upřednostnit ty, kteří mají lepší šance,
Nebo prostě nemají vybavení, které by jim pomohlo, uvedli lékaři.
Před dvěma týdny čtyři novorozenci, kteří lapali po dechu, se udusili k smrti poté, co výbuch snížil přísun kyslíku do jejich inkubátorů.
Lapali po dechu, jejich životy skončily dřív, než skutečně začaly.
V posledních týdnech síly věrné Bašáru Asadovi podporované ruskými silami ovládly povstalecké východní Aleppo s přes 200 000 lidí stále uvězněných uvnitř bez dodávek potravin.
Povstalcům, kteří jsou pod neustálým útokem ruského a syrského letectva, se v sobotu podařilo prolomit obklíčení a zahájit protiofenzivu.
Obě strany přidaly posily jak ve městě, tak v okolních oblastech.
