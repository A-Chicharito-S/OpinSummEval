Nedávné nabídky evakuace obyvatel od syrského režimu a Ruska zní jako jen lehce zastřené výhrůžky, podotkli pediatři, chirurgové a další lékaři.
Lékaři uvedli, že za uplynulý měsíc bylo zaznamenáno 42 útoků na lékařská zařízení v Sýrii, z toho 15 na nemocnice, ve kterých pracují.
Nejvíce smutní jsme z toho, že musíme rozhodovat o tom, kdo bude žít a kdo zemře.
Na pohotovost k nám přicházejí malé děti s tak vážnými zraněními, že musíme mezi nimi vybírat ty, u nichž je největší pravděpodobnost, že přežijí.
A někdy nemáme ani potřebný materiál, abychom jim pomohli, popsali lékaři.
Před dvěma týdny se udusili čtyři novorozenci, když výbuch přerušil dodávky kyslíku do jejich inkubátorů.
Lapali po dechu a pak jejich život skončil - dřív, než skutečně mohl začít, připomněli.
Armáda věrná prezidentovi Bašáru Asadovi, kterou podporují ruské síly, v minulých týdnech obklíčila povstalci ovládanou východní část Halabu, uvnitř se ocitlo bez dodávek potravin přes 200.000 lidí.
Rebelům, kteří jsou pod neustálými údery ruského a syrského letectva, se v sobotu po třech týdnech podařilo obklíčení prolomit a zahájit protiofenzivu.
Oběma stranám poté přibyly ve městě a jeho okolí posily.
