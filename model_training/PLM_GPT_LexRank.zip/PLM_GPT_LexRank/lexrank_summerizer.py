import os
from lexrank import LexRank
from lexrank.mappings.stopwords import STOPWORDS
import json
from tqdm import tqdm
from calculate_rouge import calculate


class LexRankSummarizer:
    def __init__(self, part, threshold=0.1, file_path='data/yelp'):
        self.file_path = file_path
        self.part = [part] if isinstance(part, str) else part
        self.threshold = threshold
        self.documents = self.make_corpus()

    def make_corpus(self):
        corpus = []
        # [[snt1, ..., sntN], [...], ...]
        for part in self.part:
            if part == 'train' or part == 'dev':
                bus_ids = []
                f = open(self.file_path + '/' + part + '.sum.jsonl', 'r')
                for line in tqdm(f):
                    inst = json.loads(line)
                    id = inst["business_id"]
                    if id in bus_ids:
                        continue
                    else:
                        bus_ids.append(id)
                    one_doc = [inst["summary"]] + inst["reviews"]
                    corpus.append(one_doc)
                f.close()
        return corpus

    def summarize(self):
        file_dir = 'output/yelp/lexrank'
        os.makedirs(file_dir, exist_ok=True)
        f = open(self.file_path + '/test.sum.jsonl', 'r')
        f_pred = open(file_dir + '/pred_' + '_'.join(self.part) + '.jsonl', 'w')
        if 'test' in self.part:
            for line in tqdm(f):
                inst = json.loads(line)
                revs = inst["reviews"]
                summ = inst["summary"]
                bus_id = inst["business_id"]
                test_lxr = LexRank(self.documents + [revs], stopwords=STOPWORDS['en'])
                pred = test_lxr.get_summary(revs, summary_size=1, threshold=self.threshold)[0]
                r1, r2, rL = calculate(gold_sums=summ, pred_sums=pred)
                new_inst = {'pred': pred, 'summary': summ, 'revs': revs, "business_id": bus_id, "avrR": (r1+r2+rL)/3}
                f_pred.write(json.dumps(new_inst) + '\n')
            f.close()
            f_pred.close()
        else:
            lxr = LexRank(self.documents, stopwords=STOPWORDS['en'])
            for line in tqdm(f):
                inst = json.loads(line)
                revs = inst["reviews"]
                summ = inst["summary"]
                bus_id = inst["business_id"]
                pred = lxr.get_summary(revs, summary_size=1, threshold=self.threshold)[0]
                r1, r2, rL = calculate(gold_sums=summ, pred_sums=pred)
                new_inst = {'pred': pred, 'summary': summ, 'revs': revs, "business_id": bus_id, "avrR": (r1+r2+rL)/3}
                f_pred.write(json.dumps(new_inst) + '\n')
            f.close()
            f_pred.close()


if __name__ == '__main__':
    TrainOnlySummarizer = LexRankSummarizer(part=["train"])
    TrainOnlySummarizer.summarize()

    DevOnlySummarizer = LexRankSummarizer(part=["dev"])
    DevOnlySummarizer.summarize()

    TestOnlySummarizer = LexRankSummarizer(part=["test"])
    TestOnlySummarizer.summarize()

    TrainAndDevSummarizer = LexRankSummarizer(part=["train", "dev"])
    TrainAndDevSummarizer.summarize()

    file_list = os.listdir('output/yelp/lexrank')
    total_insts = {}
    type_cnt = {}
    for file_path in file_list:
        f = open('output/yelp/lexrank/'+file_path, 'r')
        for line in tqdm(f):
            inst = json.loads(line)
            id = inst["business_id"]
            name_avrR = (file_path, inst["avrR"])
            if id not in total_insts.keys():
                total_insts[id] = [name_avrR]
            else:
                total_insts[id].append(name_avrR)
    for key in list(total_insts.keys()):
        name_avrR_list = total_insts[key]  # [{xxx: avrR}, {...}, ...]
        name_avrR_list.sort(key=lambda x: x[1], reverse=True)
        max_avrR = name_avrR_list[0][1]
        for name_avrR in name_avrR_list:
            name, avrR = name_avrR
            if name not in type_cnt.keys():
                type_cnt[name] = 0
            if avrR == max_avrR:
                type_cnt[name] += 1
    for name in type_cnt.keys():
        print('type: {}, max_avr_ROUGE percent: {}'.format(name, type_cnt[name]/100))







