import argparse

import json
import numpy as np

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import random

from transformers import AutoConfig
from transformers import AutoTokenizer
from transformers import AutoModelForSeq2SeqLM as Model
from transformers import Adafactor
from transformers import get_cosine_schedule_with_warmup
import time
import os
from tqdm import tqdm

from calculate_rouge import calculate
from data_pipeline import SummarizationDataset


def train(args):
    print(args)

    print('Preparing data...')

    if args.train_file is None:
        train_file = args.data_dir + '/' + args.dataset + '/train.sum.jsonl'
    else:
        train_file = args.train_file
    dataset = SummarizationDataset(train_file, )
    dataloader = DataLoader(dataset, batch_size=args.batch_size)

    if args.gen_dev_file is None:
        gen_dev_file = args.data_dir + '/' + args.dataset + '/dev.sum.jsonl'
    else:
        gen_dev_file = args.gen_dev_file
    gen_dev_dataset = SummarizationDataset(gen_dev_file, shuffle=False)
    gen_dev_dataloader = DataLoader(gen_dev_dataset, batch_size=args.batch_size)
    f = open(gen_dev_file, 'r')
    lines = f.readlines()
    data = [json.loads(line) for line in lines]
    f.close()
    gen_gold_sums = [inst['summary'].lower() for inst in data]

    print('Initializing model...')

    tokenizer = AutoTokenizer.from_pretrained(args.model_type)
    config = AutoConfig.from_pretrained(args.model_type)
    pad_token_id = config.pad_token_id
    num_enc = config.num_layers
    num_dec = config.num_decoder_layers
    print('In the T5 model # of encoders: {}, # of decoders: {}'.format(num_enc, num_dec))
    print(config.dropout_rate)

    model = Model.from_pretrained(args.model_type, return_dict=True)
    model.resize_token_embeddings(len(tokenizer))
    model.cuda()
    model.parallelize()
    optimizer = Adafactor(model.parameters(), lr=args.learning_rate, relative_step=False)

    step = 0
    best_rouge = 0
    best_step = 0
    if args.load_model is not None:
        print('Loading model...')
        best_point = torch.load(args.load_model)
        model.load_state_dict(best_point['model'])
        optimizer.load_state_dict(best_point['optimizer'])
        step = best_point['step']

    print('Start training...')

    while step < args.no_train_steps:
        losses = []
        for _, (inp_batch, out_batch) in enumerate(tqdm(dataloader)):

            model.train()

            batch_encoding = tokenizer(list(inp_batch), padding=True, max_length=args.max_length,
                                       truncation=True, return_tensors='pt')
            with tokenizer.as_target_tokenizer():
                labels = tokenizer(list(out_batch), padding=True, max_length=args.max_target_length,
                                   truncation=True, return_tensors='pt')
            batch_encoding["labels"] = labels["input_ids"]

            inp_ids = batch_encoding['input_ids'].cuda()
            inp_mask = batch_encoding['attention_mask'].cuda()
            out_ids = batch_encoding['labels'].cuda()
            out_ids[out_ids == pad_token_id] = -100
            dec_inp_ids = model._shift_right(out_ids)


            model_outputs = model(input_ids=inp_ids,
                                  attention_mask=inp_mask,
                                  decoder_input_ids=dec_inp_ids,
                                  labels=out_ids)

            loss = model_outputs.loss
            losses.append(loss.item())

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            step += 1
            if step % args.check_every == 0:
                print('Step %d Loss %.4f' % (step, np.mean(losses)))
                print('best ROUGE: {}, best step: {}'.format(best_rouge, best_step))
                model.eval()

                rouge_scores = []

                # generate general summaries
                gen_pred_sums = []
                for _, (dev_inp_batch, _) in enumerate(tqdm(gen_dev_dataloader)):
                    batch_encoding = tokenizer(list(dev_inp_batch), padding=True, max_length=args.max_length,
                                               truncation=True, return_tensors='pt')

                    inp_ids = batch_encoding['input_ids'].cuda()

                    preds = model.generate(
                        inp_ids,
                        min_length=args.min_target_length,
                        max_length=args.max_target_length * 2,
                        num_beams=args.num_beams,
                    )

                    for pred in preds:
                        gen_pred_sums.append(tokenizer.decode(pred, skip_special_tokens=True))

                gen_scores = calculate(gen_gold_sums, gen_pred_sums)
                rouge_scores += list(gen_scores)

                rouge = np.power(np.product(rouge_scores), 1.0 / len(rouge_scores))

                print("ROUGE: %.4f" % rouge)
                print("Gold:", gen_gold_sums[0])
                print("Pred:", gen_pred_sums[0])

                if rouge > best_rouge:
                    if best_step != 0:
                        prev_path = args.model_dir + '/' + args.dataset + '/' + args.round + args.model_name + '.best.%d.%.3f' % (
                            best_step, best_rouge)
                        os.remove(prev_path)
                    print('Saving...')
                    best_rouge = rouge
                    best_step = step
                    torch.save({
                        'model': model.state_dict(),
                        'optimizer': optimizer.state_dict(),
                        'step': step,
                        'loss': np.mean(losses)
                    }, args.model_dir + '/' + args.dataset + '/' + args.round + args.model_name + '.best.%d.%.3f' % (
                        step, rouge))

            if step > best_step + args.patience:
                print('ran out of patience')
                return
            if step == args.no_train_steps:
                break


def evaluate(args):
    print(args)

    print('Preparing data...')

    if args.gen_test_file is None:
        test_file = args.data_dir + '/' + args.dataset + '/test.sum.jsonl'
    else:
        test_file = args.gen_test_file
    dataset = SummarizationDataset(test_file, shuffle=False)
    dataloader = DataLoader(dataset, batch_size=args.batch_size)
    f = open(test_file, 'r')
    lines = f.readlines()
    data = [json.loads(line) for line in lines]
    f.close()
    gold_sums = [inst['summary'].lower() for inst in data]
    pred_sums = []
    revs = []

    print('Initializing model...')
    tokenizer = AutoTokenizer.from_pretrained(args.model_type)

    model = Model.from_pretrained(args.model_type, return_dict=True)
    model.resize_token_embeddings(len(tokenizer))
    model.cuda()

    assert args.load_model is not None
    best_point = torch.load(args.load_model)
    model.load_state_dict(best_point['model'])
    os.makedirs('output/' + args.dataset + '/' + args.model_type, exist_ok=True)
    f = open('output/' + args.dataset + '/' + args.model_type + '/' + args.round + '.out', 'w')
    for _, (inp_batch, _) in enumerate(tqdm(dataloader)):
        model.eval()

        batch_encoding = tokenizer(list(inp_batch), padding=True, max_length=args.max_length,
                                   truncation=True, return_tensors='pt')
        inp_ids = batch_encoding['input_ids'].cuda()
        preds = model.generate(
            inp_ids,
            min_length=args.min_target_length,
            max_length=args.max_target_length * 2,
            num_beams=args.num_beams,
        )
        # TODO: add a module to calculate the ROUGE
        for pred in preds:
            pred_sums.append(tokenizer.decode(pred, skip_special_tokens=True))
        for rev in inp_batch:
            revs.append(rev)
    assert len(pred_sums) == len(gold_sums)
    assert len(revs) == len(pred_sums)
    R1, R2, RL = [], [], []
    for i, pred_sum in enumerate(pred_sums):
        r1, r2, rL = calculate(gold_sums=gold_sums[i], pred_sums=pred_sum)
        R1.append(r1)
        R2.append(r2)
        RL.append(rL)
        inst = {'summary': gold_sums[i], 'pred': pred_sum, 'revs': revs[i], 'R1': r1, "R2": r2, "RL": rL,
                "business_id": data[i]["business_id"], "number": i + 1}
        f.write(json.dumps(inst) + '\n')
    f.close()
    print('avr R1: {}\n avr R2: {}\n avr RL: {}'.format(np.mean(R1), np.mean(R2), np.mean(RL)))
    new_f = open('output/' + args.dataset + '/' + args.model_type + '/' + args.round + '_ROUGE.txt', 'w')
    new_f.write('avr R1: {}\navr R2: {}\navr RL: {}\navr ROUGE: {}'.format(np.mean(R1), np.mean(R2), np.mean(RL), (
                np.mean(R1) + np.mean(R2) + np.mean(RL)) / 3))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    parser.add_argument('-mode', default='train', type=str)

    parser.add_argument('-dataset', default='yelp', type=str)
    parser.add_argument('-model_name', default='sum', type=str)
    parser.add_argument('-load_model', default=None, type=str)

    parser.add_argument('-train_file', default=None, type=str)
    parser.add_argument('-gen_dev_file', default=None, type=str)
    parser.add_argument('-gen_test_file', default=None, type=str)

    parser.add_argument('-data_dir', default='data', type=str)
    parser.add_argument('-model_dir', default='model', type=str)

    parser.add_argument('-model_type', default='t5-base', type=str)  # google/flan-t5-base, t5-base

    parser.add_argument('-batch_size', default=16, type=int)
    parser.add_argument('-learning_rate', default=1e-3, type=float)  # 1e-3
    parser.add_argument('-no_train_steps', default=100000, type=int)  # 500000
    parser.add_argument('-no_warmup_steps', default=20000, type=int)  # 20000
    parser.add_argument('-check_every', default=1000, type=int)  # 1000
    parser.add_argument('-ckpt_every', default=10000, type=int)  # 10000

    parser.add_argument('-max_length', default=512, type=int)

    parser.add_argument('-min_target_length', default=60, type=int)
    parser.add_argument('-max_target_length', default=128, type=int)
    parser.add_argument('-num_beams', default=2, type=int)
    # parser.add_argument('-no_repeat_ngram_size', default=2, type=int)
    # parser.add_argument('-repetition_penalty', default=1, type=float)
    # parser.add_argument('-length_penalty', default=1, type=float)
    parser.add_argument('-round', default=None, type=str)
    parser.add_argument('-patience', default=20000, type=int)

    args = parser.parse_args()
    import pandas

    df = pandas.read_csv('summaries_0-200_cleaned.csv')

    dev_length = [len(item.strip().split()) for item in list(dict(df['Answer.summary']).values())[:100]]
    min_dev = min(dev_length)
    max_dev = max(dev_length)

    inst_length_list = []
    for i, row in df.iterrows():  # we here use the dev set
        if i == 100:
            break
        inst_length = 0
        for idx in range(8):
            rev_key = "Input.original_review_" + str(idx)
            inst_length += len(row[rev_key].split())
        inst_length_list.append(inst_length)
    assert len(inst_length_list) == 100
    approx_max_revs_words = max(inst_length_list)

    args.max_length = (int(approx_max_revs_words / 10) + 1) * 10

    if args.mode == 'train':
        args.min_target_length = min_dev
        args.max_target_length = max_dev
        for i in range(3):
            args.round = str(i + 1)
            train(args)
    else:
        args.min_target_length = min_dev
        args.max_target_length = max_dev
        evaluate(args)
