"""{"summary": snt x 1, "reviews": [snt x N], "business_id": xxx}"""
import json
import pandas
from tqdm import tqdm
from copy import deepcopy
from calculate_rouge import calculate
from random import shuffle
import random
from yelp_exclude import Yelp_Dev, Yelp_Test


class YelpProcessor:
    def __init__(self, file_dir, max_revs_words, min_rev_length=20, max_rev_length=70, min_num_revs=10, percent=0.1):
        # similar to CopyCat procedure
        self.file_dir = file_dir
        self.train_file_path = file_dir + '/train.sum.jsonl'
        self.dev_file_path = file_dir + '/dev.sum.jsonl'
        self.test_file_path = file_dir + '/test.sum.jsonl'
        self.file_path = file_dir + '/yelp_academic_dataset_review.json'
        self.max_revs_words = max_revs_words
        self.max_rev_length = max_rev_length
        self.min_rev_length = min_rev_length
        self.min_num_revs = min_num_revs
        self.percent = percent
        self.bus_revs = {}

    def load_reviews(self):
        f = open(self.file_path, 'r')
        new_f = open(self.file_dir + '/loaded_revs.jsonl', 'w')
        for line in tqdm(f):
            inst = json.loads(line)
            bus_id = inst["business_id"]
            text = inst["text"]
            text_length = len(text.strip().split())
            if self.max_rev_length < text_length or self.min_rev_length > text_length:
                continue
            if bus_id in Yelp_Dev or bus_id in Yelp_Test:
                continue
            if bus_id not in self.bus_revs.keys():
                self.bus_revs[bus_id] = [text]
            else:
                self.bus_revs[bus_id].append(text)
            new_f.write(json.dumps({"text": text, "bus_id": bus_id})+'\n')
        f.close()
        new_f.close()

    def create_train(self):
        """
        select reviews based on random sampling (which approximately reduced 2.5M pseudo revs-summ paris to: 250K [rate of 0.1])
        """
        assert len(self.bus_revs) != 0
        cnt = 0

        sum_revs_list = []
        for bus_id in tqdm(self.bus_revs.keys()):
            if len(self.bus_revs[bus_id]) < self.min_num_revs:
                continue
            total_text_length = len(" ".join(self.bus_revs[bus_id]).strip().split())
            for i, pseudo_sum in enumerate(self.bus_revs[bus_id]):  # interleavingly create pseudo revs for each snt
                pseudo_sum_length = len(pseudo_sum.strip().split())
                if pseudo_sum_length >= int(total_text_length / 2):
                    # to prevent summary from being longer than reviews
                    continue
                pseudo_revs = deepcopy(self.bus_revs[bus_id])
                pseudo_revs.pop(i)
                shuffle(pseudo_revs)
                sum_revs_inst = {"summary": pseudo_sum, "reviews": pseudo_revs, "business_id": bus_id,
                                 "rev_length": total_text_length - pseudo_sum_length}
                sum_revs_list.append(sum_revs_inst)
                cnt += 1

        f = open(self.train_file_path, 'w')
        sorted_sum_revs_list = sorted(sum_revs_list, key=lambda x: x["rev_length"])
        sorted_cnt = 0
        for i in range(10):
            one_slice = deepcopy(sorted_sum_revs_list[int(cnt * (i / 10)):int(cnt * ((i + 1) / 10))])
            shuffle(one_slice)
            slice_length = len(one_slice)
            one_slice = one_slice[:int(self.percent * slice_length)]
            for sorted_sum_revs_inst in tqdm(one_slice):
                sorted_sum_revs_inst.pop("rev_length")
                sorted_sum_revs_inst["reviews"] = ' '.join(' '.join(sorted_sum_revs_inst["reviews"]).split()[:self.max_revs_words])
                # truncate the input reviews to speed up tokenization time during training
                f.write(json.dumps(sorted_sum_revs_inst) + '\n')
                sorted_cnt += 1
        f.close()
        print('total number of pseudo revs-sum pairs: {}'.format(sorted_cnt))

    def create_dev_test(self):
        df = pandas.read_csv('summaries_0-200_cleaned.csv')
        dev_f = open(self.dev_file_path, 'w')
        test_f = open(self.test_file_path, 'w')
        for i, row in df.iterrows():

            revs = [row['Input.original_review_0'], row['Input.original_review_1'], row['Input.original_review_2'],
                    row['Input.original_review_3'], row['Input.original_review_4'], row['Input.original_review_5'],
                    row['Input.original_review_6'], row['Input.original_review_7']]
            summary = row['Answer.summary']
            inst = {"summary": summary, "reviews": ' '.join(revs), "business_id": i}
            if i < 100:
                dev_f.write(json.dumps(inst) + '\n')
            else:
                test_f.write(json.dumps(inst) + '\n')

    def recover_from_loaded_revs(self):
        """
        used when your server is slow to upload data, it recovers the loaded reviews from "load_reviews()"
        """
        f = open(self.file_dir + '/loaded_revs.jsonl', 'r')
        assert len(self.bus_revs) == 0
        for line in tqdm(f):
            inst = json.loads(line)
            text = inst["text"]
            bus_id = inst["bus_id"]
            if bus_id not in self.bus_revs.keys():
                self.bus_revs[bus_id] = [text]
            else:
                self.bus_revs[bus_id].append(text)

    def process(self):
        print('Loading all the reviews...')
        self.load_reviews()
        print('Creating training set...')
        self.create_train()
        print('Creating dev/test set...')
        self.create_dev_test()


if __name__ == '__main__':
    seed = 5
    random.seed(seed)
    # make sure the shuffle process is not random
    df = pandas.read_csv('summaries_0-200_cleaned.csv')
    inst_length_list = []
    for i, row in df.iterrows():  # we here use the dev set
        if i == 100:
            break
        inst_length = 0
        for idx in range(8):
            rev_key = "Input.original_review_"+str(idx)
            inst_length += len(row[rev_key].split())
        inst_length_list.append(inst_length)
    assert len(inst_length_list) == 100
    approx_max_revs_words = max(inst_length_list)

    yelp_processor = YelpProcessor(file_dir='data/yelp', max_revs_words=(int(approx_max_revs_words / 10) + 1) * 10)
    yelp_processor.process()
    # yelp_processor.recover_from_loaded_revs()
    # yelp_processor.create_train()
    # yelp_processor.create_dev_test()
