import json
import openai
import pandas
from tqdm import tqdm
import os

openai.api_key = "YOUR API-KEY HERE"

df = pandas.read_csv('summaries_0-200_cleaned.csv')
dev_length = [len(item.strip().split()) for item in list(dict(df['Answer.summary']).values())[:100]]
max_tokens_dev = int(max(dev_length) / 0.75)
# the documentation: "As a rough rule of thumb, 1 token is approximately 4 characters or 0.75 words for English text."
print('max generation token # is: {}'.format(max_tokens_dev))

f = open('data/yelp/test.sum.jsonl', 'r')
os.makedirs('output/yelp/gpt')
gpt_f = open('output/yelp/gpt/output.jsonl', 'w')
for line in tqdm(f):
    inst = json.loads(line)
    gpt_prompt = ' '.join(inst["reviews"])+'\n\nTl;dr'
    response = openai.Completion.create(
        model="text-davinci-003",
        prompt=gpt_prompt,
        temperature=0.0,  # we want it to be as deterministic as possible
        max_tokens=max_tokens_dev,
        top_p=1.0,  # default as the provided example in "https://platform.openai.com/examples/default-tldr-summary"
        frequency_penalty=0.0,  # default in "https://platform.openai.com/examples/default-tldr-summary"
        presence_penalty=1  # default in "https://platform.openai.com/examples/default-tldr-summary"
    )
    inst["gpt_response"] = response
    gpt_f.write(json.dumps(inst)+'\n')
