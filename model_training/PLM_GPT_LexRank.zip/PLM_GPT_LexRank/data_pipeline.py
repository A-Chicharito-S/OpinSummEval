import json
import random
from torch.utils.data import IterableDataset


class SummarizationDataset(IterableDataset):

    def __init__(self, file, shuffle=True):
        if type(file) is str:
            self.files = [file]
        elif type(file) is list:
            self.files = file
        self.shuffle = shuffle
        self.buffer_size = 4096

    def process(self, inst):
        if type(inst) is str:
            try:
                inst = json.loads(inst)
            except:
                print(inst)
                exit()

        inp = inst['reviews'].lower()

        if type(inst['summary']) is list:
            inst['summary'] = inst['summary'][0]
        out = inst['summary'].lower()

        return inp, out

    def __iter__(self):
        if self.shuffle:
            dataset_iters = [open(file, 'r') for file in self.files]
            shufbuf = []
            try:
                for i in range(self.buffer_size // len(self.files)):
                    for file_idx, dataset_iter in enumerate(dataset_iters):
                        item = json.loads(next(dataset_iter).strip())
                        shufbuf.append(item)
                self.buffer_size = len(shufbuf)
            except:
                self.buffer_size = len(shufbuf)

            try:
                while True:
                    for i, dataset_iter in enumerate(dataset_iters):
                        try:
                            item = json.loads(next(dataset_iter).strip())
                            evict_idx = random.randint(0, self.buffer_size - 1)
                            yield self.process(shufbuf[evict_idx])
                            shufbuf[evict_idx] = item
                        except StopIteration:
                            dataset_iters[i].close()
                            dataset_iters[i] = open(self.files[i], 'r')
                # while len(shufbuf) > 0:
                #  yield self.process(shufbuf.pop())
            except GeneratorExit:
                pass

            for dataset_iter in dataset_iters:
                dataset_iter.close()

        else:
            for file_idx, file in enumerate(self.files):
                f = open(file, 'r')
                for line in f:
                    yield self.process(line)
                f.close()


"""data format: {"text": xxx } """


class ReconstructionDataset(IterableDataset):

    def __init__(self, file, shuffle=True):
        if type(file) is str:
            self.files = [file]
        elif type(file) is list:
            self.files = file
        self.shuffle = shuffle
        self.buffer_size = 4096

    def process(self, inst):
        if type(inst) is str:
            try:
                inst = json.loads(inst)
            except:
                print(inst)
                exit()

        inp_out = inst['text'].lower()

        return inp_out, inp_out

    def __iter__(self):
        if self.shuffle:
            dataset_iters = [open(file, 'r') for file in self.files]
            shufbuf = []
            try:
                for i in range(self.buffer_size // len(self.files)):
                    for file_idx, dataset_iter in enumerate(dataset_iters):
                        item = json.loads(next(dataset_iter).strip())
                        shufbuf.append(item)
                self.buffer_size = len(shufbuf)
            except:
                self.buffer_size = len(shufbuf)

            try:
                while True:
                    for i, dataset_iter in enumerate(dataset_iters):
                        try:
                            item = json.loads(next(dataset_iter).strip())
                            evict_idx = random.randint(0, self.buffer_size - 1)
                            yield self.process(shufbuf[evict_idx])
                            shufbuf[evict_idx] = item
                        except StopIteration:
                            dataset_iters[i].close()
                            dataset_iters[i] = open(self.files[i], 'r')
                # while len(shufbuf) > 0:
                #  yield self.process(shufbuf.pop())
            except GeneratorExit:
                pass

            for dataset_iter in dataset_iters:
                dataset_iter.close()

        else:
            for file_idx, file in enumerate(self.files):
                f = open(file, 'r')
                for line in f:
                    yield self.process(line)
                f.close()
